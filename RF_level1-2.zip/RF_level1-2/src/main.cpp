#include <Arduino.h>

#define LOW_SPEED 125
#define MAX_SPEED 255

uint32_t Data = 0;
long MeasureDistance = 0;
uint8_t LdrMapped = 0;
float Temp = 0;
float Humid = 0;

void SensorAndLedSetup();
void Dht();
void Ldr();
void Ultrasonic();
void MotorDriveSetup();
void Welcome();
void BuzzerOn();
void BuzzerOff();
void Backward(uint8_t Speed);
void RotateRight(uint8_t Speed);
void RotateLeft(uint8_t Speed);
void SlideLeftForward(uint8_t Speed);
void SlideRightForward(uint8_t Speed);
void SlideLeftBackward(uint8_t Speed);
void SlideRightBackward(uint8_t Speed);
void SlideLeft(uint8_t Speed);
void Forward(uint8_t Speed);
void SlideRight(uint8_t Speed);
void FrontLedOn();
void DisplayOff();
void Stop();
void FrontLedOff();
void DisplayLcd(uint8_t Row1,String Text1,uint8_t Row2,String Text2);
void LightStop();
void ForwardToWall(uint32_t Speed, uint32_t Distance);
void BuzzerBlink();


/*-----------------------------------------------*/
void setup() {
  //setupOTA();
  Serial.begin(9600);
  SensorAndLedSetup();
  MotorDriveSetup();
  Serial.println("Level1-2");
  Welcome();

}
/*-----------------------------------------------*/
void loop() {
  //ArduinoOTA.handle();
  if (Serial.available() > 0) {
    int newData = Serial.parseInt();
    if (newData != 0) {
      Data = newData;
    }
  }
  switch (Data) {
    case 10:  //Display Sensor
      Dht();
      delay(1000);
      Ldr();
      delay(1000);
      Ultrasonic();
      delay(1000);
      break;

    case 11:  //Autocar
      ForwardToWall(MAX_SPEED,20);
      DisplayLcd(0, "Detect obstacles", 0, "");
      Backward(LOW_SPEED);
      delay(500);
      RotateRight(LOW_SPEED);
      delay(500);
      break;
    
    // case 3:  //Eye Color Environment current not use
    //   break;
      
    case 13:  //Speak
      BuzzerOn();
      delay(500);
      BuzzerOff();
      delay(100);
      BuzzerOn();
      delay(200);
      BuzzerOff();
      delay(100);
      BuzzerOn();
      delay(200);
      BuzzerOff();
      break;

    case 14: //Car is a Triangle
      DisplayLcd(0, "Car's a triangle", 0, "");
      SlideRightForward(MAX_SPEED);
      delay(2000);
      SlideRightBackward(MAX_SPEED);
      delay(2000);
      SlideLeft(MAX_SPEED);
      delay(2000);
      break;

    case 15: //Car is a Rectangle
      DisplayLcd(0, "Car's Rectangle", 0, "");
      Forward(LOW_SPEED);
      delay(2000);
      SlideRight(MAX_SPEED);
      delay(2000);
      Backward(LOW_SPEED);
      delay(2000);
      SlideLeft(MAX_SPEED);
      delay(2000);
      break;

    case 16: //Flashlight
      DisplayLcd(1, "Flashlight ON", 0, "");
      FrontLedOn();
      break;

    case 12://Stop
      DisplayOff();
      BuzzerOff();
      Stop();
      FrontLedOff();
      break;

    case 17://Reset
      ESP.restart();
      break;
      
  }
}
void LightStop()
{
  Ldr();
  if(LdrMapped < 15)
  {
    Data = 8;
  }
}
void ForwardToWall(uint32_t Speed, uint32_t Distance)
{
  int i = 1;
  do
  {
    Ultrasonic();
    if((MeasureDistance < Distance) && (MeasureDistance > 0))
    {
      Stop();
      delay(10);
      i--;
    }
    else
    {
      DisplayLcd(4, "Auto Car", 0, "");
      Forward(Speed);
      LightStop();
    }
  }while(i);
}